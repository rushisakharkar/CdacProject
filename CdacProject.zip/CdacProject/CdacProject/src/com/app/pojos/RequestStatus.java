package com.app.pojos;

public enum RequestStatus {
	NOREQUEST,ACCEPTED,REJECTED,PENDING

}
