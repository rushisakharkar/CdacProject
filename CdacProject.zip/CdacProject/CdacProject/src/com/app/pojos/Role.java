package com.app.pojos;

public enum Role {
	ADMIN,DATAOPERATOR

}
