package com.app.pojos;

public enum CollegeRole {
	COLLEGE

}
